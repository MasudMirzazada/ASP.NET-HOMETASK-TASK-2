$('.myslider').slick({
    slidesToShow: 3,
  slidesToScroll: 1,
  infinite: true,
  autoplay: true,
  autoplaySpeed: 2000,
  });
  $(".slick-next").html(`<i class="fa-solid fa-arrow-right"></i>`)
  $(".slick-prev").html(`<i class="fa-solid fa-arrow-left"></i>`)