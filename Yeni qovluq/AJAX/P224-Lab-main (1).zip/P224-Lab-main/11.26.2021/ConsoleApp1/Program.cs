﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Task1
            //int a = 7;
            //int b = 5;
            //a = a + b;
            //b = a - b;
            //a = a - b;
            //Console.WriteLine("a="+a+" b="+b);
            #endregion
            #region Task2
            //int num = 0, factorial=1;
            //for (int i = 2; i <= num; i++)
            //{
            //    factorial = factorial* i;
            //}
            //Console.WriteLine(factorial);
            #endregion
            #region Task3
            //int number = 6;
            //int counter = 0;
            //for (int i = 1; i <= number; i++)
            //{
            //    if (number%i==0)
            //    {
            //        counter++;
            //    }
            //}
            //Console.WriteLine(counter);
            #endregion
            // Example: 3743 => 7+3 = 10
            #region Task4
            //int num = 567;
            //int copy = num;
            //int digitCount = 0;
            //int rem,sum=0,counter;
            //while (num > 0)
            //{
            //    num /= 10;
            //    digitCount++;
            //}
            //if (digitCount % 2 == 0)
            //{
            //    counter = 0;
            //}
            //else
            //{
            //    counter = 1;
            //}
            //while (copy>0)
            //{
            //    rem = copy % 10;
            //    if (counter%2==0)
            //    {
            //        sum += rem;
            //    }
            //    copy /= 10;
            //    counter++;
            //}
            //Console.WriteLine(sum);
            #endregion
        }
    }
}
